Visit the project page for details about these builds and the list of changes:

   https://github.com/vszakats/harbour-deps

Please donate to support maintaining these builds:

   PayPal:
      https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2DZM6WAGRJWT6

Thank you!
